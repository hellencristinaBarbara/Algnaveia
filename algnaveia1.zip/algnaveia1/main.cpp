#include <iostream> // A biblioteca <iostream> está mantida

int main() {
    // Declaração das variáveis
    int a, b, c;
    int soma;

    // Atribuição de valores às variáveis (exemplo)
    a = 10;
    b = 10;
    c = 15;

    // Cálculo da soma das variáveis
    soma = a + b + c;

    // Exibir o resultado da soma
    printf("Soma = %d\n", soma);

    return 0;
}
